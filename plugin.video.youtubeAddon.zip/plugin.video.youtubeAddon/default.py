# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2015 - Simple TechNerd
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.youtubeAddon'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("budhasubbamusic", "user/budhasubbamusic", 'https://yt3.ggpht.com/-wSUSoF6s1z4/AAAAAAAAAAI/AAAAAAAAAAA/8YLLTKeWuO0/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("highlightsnepal", "user/highlightsnepal2009", 'https://yt3.ggpht.com/-Q0gwLJCTgWA/AAAAAAAAAAI/AAAAAAAAAAA/qF8_x9eR6kA/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("OSR Digital", "channel/UCxCoea3ulOukfXiYAm87ZIA", 'https://yt3.ggpht.com/-QpKYSBtce0s/AAAAAAAAAAI/AAAAAAAAAAA/F55lrgzUUCg/s900-c-k-no-mo-rj-c0xffffff/photo.jpg'),				
]



# Entry point
def run():
    plugintools.log("youtubeAddon.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("youtubeAddon.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()