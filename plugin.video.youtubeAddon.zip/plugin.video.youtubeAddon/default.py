# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2015 - Simple TechNerd
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import urllib
import urllib2
import xbmc,xbmcaddon
from addon.common.addon import Addon
import requests
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP

addonID = 'plugin.video.youtubeAddon'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')



def makeRequest(url, headers=None):
        
    if headers is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0'}
    req = urllib2.Request(url,None,headers)
    response = urllib2.urlopen(req)
    data = response.read()
    response.close()
    return data
        

# Entry point
def run():
    plugintools.log("youtubeAddon.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("youtubeAddon.main_list "+repr(params))

url='https://simplekore.com/wp-content/uploads/file-manager/askshre/Youtube/youtube.txt'
if url.startswith('http://') or url.startswith('https://'):
    data = makeRequest(url)
    soup =BeautifulSOAP(data, convertEntities=BeautifulStoneSoup.XML_ENTITIES)
if len(soup('item')) > 0:
    items = soup('item')
    for item in items:
        linkedUrl =  item('utube')[0].string
        name = item('title')[0].string
        icon=item('thumbnail')[0].string
        plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+linkedUrl+"/",thumbnail=icon,folder=True )

run()