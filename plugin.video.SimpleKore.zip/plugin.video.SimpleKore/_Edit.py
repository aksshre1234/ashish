import xbmcaddon

MainBase = 'https://goo.gl/yU8hjI'
addon = xbmcaddon.Addon('plugin.video.SimpleKore')